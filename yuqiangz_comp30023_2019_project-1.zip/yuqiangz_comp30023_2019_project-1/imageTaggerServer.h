/**
 * COMP30023 Project 1
 * This header file imageTaggerServer.h is used in image_tagger.c 
 * Name: Yuqiang Zhu. ID: 853912
 * Email: yuqiangz@student.unimelb.edu.au
 */
void runServer(char *mainProgram, char *ip, char *port);